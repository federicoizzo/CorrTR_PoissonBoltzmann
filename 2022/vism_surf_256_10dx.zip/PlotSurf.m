function p = PlotSurf( X,Y,Z,phi,a,varargin)
% PlotSurf(X,Y,Z,phi,a=iso level) plot isosurface

% defaultarg = {'FaceAlpha','0.5','FaceColor',[200, 150, 0]/255};

bound = max(X(:));

p = patch(isosurface(X,Y,Z,phi,a),varargin{:});
isonormals(X,Y,Z,phi,p);

xlim([-bound, bound])
ylim([-bound, bound])
zlim([-bound, bound])
daspect([1 1 1])
view(3); 


% p.FaceVertexAlphaData = 0;
% p.FaceAlpha = 0.5;
% p.FaceColor = [200, 150, 0]/255;
p.EdgeColor = 'none';
% material([0.3 0.9 0.0]);
material dull;

camlight 
lighting gouraud

xlabel('x')
ylabel('y')
zlabel('z')


% grid on
end

