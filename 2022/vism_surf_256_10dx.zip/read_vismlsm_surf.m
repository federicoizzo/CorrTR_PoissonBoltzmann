function [ phi, Xcont,Ycont,Zcont ] = read_vismlsm_surf(file)
% read VISMLSM surface
if ~exist(file,'file')
    error(sprintf('file no exist:%s',file))
    return
end

file_dat = fopen(file);
fgetl(file_dat);
nx= fscanf(file_dat, '%*s %*s %d', 1);
ny= fscanf(file_dat, '%d', 1);
nz= fscanf(file_dat, '%d\n', 1);
%     disp(nx), disp(ny), disp(nz)
dx=fscanf(file_dat, '%*s %*s %lf', 1);
dy=fscanf(file_dat, '%lf', 1);
dz=fscanf(file_dat, '%lf\n', 1);
%     disp(dx), disp(dy), disp(dz)
fprintf("nx = %d, ny = %d, nz = %d, dx = %g, dy = %g, dz = %g\n",nx,ny,nz,dx,dy,dz);
A=fscanf(file_dat, '%lf', [nz, ny*nx]);
A=A.';
phi=zeros(nx, ny, nz); % phi data for continuous vism
for i=1:nx
    phi(i,:,:)=A(1+(i-1)*ny:ny*i,1:nz);
end
phi = permute(phi,[2 1 3]);
grid_cont = [-(nx-1)*dx/2:dx:(nx-1)*dx/2];
[Xcont,Ycont,Zcont] = meshgrid(grid_cont);

fclose(file_dat);
end

