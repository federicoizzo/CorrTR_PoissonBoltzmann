% surface to Richard
% p53-mdm2, tight and loose, initial, seperation d=14
%% p53mdm2

gb = 31.7945; % grid bound
yellow = [0.7843    0.5882         0];

% tight initial, the surface has two disconnected components
% sfile = 'protein_d14_tight_gn256.dat'

% loose initial, the surface has one componennt
sfile = 'protein_d14_loose_gn256.dat'


%% read surface

[phi, X,Y,Z ] = read_vismlsm_surf(sfile);
%% plot surface
close all

PlotSurf(X,Y,Z,phi,0,'FaceAlpha','1','FaceColor', yellow);

%% lighting etc
set(gca,'Visible','off')
view([0,60])

delete(findall(gcf,'Type','light'))
material dull

camproj('perspective')
camlight('left')
lighting flat
%%


